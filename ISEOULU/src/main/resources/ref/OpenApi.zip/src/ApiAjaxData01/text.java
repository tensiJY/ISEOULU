package ApiAjaxData01;

public class text {
	
	public static void main(String args[]){
		String ab = "127.0591318945";
		
		double a = Double.parseDouble(ab);
		System.out.println(a);
		
		String details = "Hello \"world\"!";
		System.out.println(details);
		
		details = details.replaceAll("\"", "");
		System.out.println(details);
	}
}
