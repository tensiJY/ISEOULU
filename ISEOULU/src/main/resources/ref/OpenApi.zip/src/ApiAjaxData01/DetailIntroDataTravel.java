package ApiAjaxData01;


import java.io.BufferedReader;
import java.io.InputStreamReader;

import java.net.HttpURLConnection;


import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.HashMap;
import java.util.Map;



import org.json.XML;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import Util.JDBCUtil;


public class DetailIntroDataTravel {
  	
	 public void detailDataGet(String serviceKey, int contentId, int contentTypeId,
			 String ourl, String id, String pw) {
    	String  xml;
    	JDBCUtil db = null;
    	Connection con = null;
    	PreparedStatement pstmt = null;
		try {

			StringBuilder urlBuilder = 
					new StringBuilder("http://api.visitkorea.or.kr/openapi/service/rest/KorService/detailIntro"); /*URL*/
			urlBuilder.append("?"+"serviceKey="+serviceKey);
			urlBuilder.append("&numOfRows=10");
			urlBuilder.append("&pageSize=10");
			urlBuilder.append("&pageNo=1");
			urlBuilder.append("&startPage=1");
			urlBuilder.append("&MobileOS="+"ETC");
			urlBuilder.append("&MobileApp="+"AppTest");
			urlBuilder.append("&introYN=Y");
			urlBuilder.append("&contentTypeId="+contentTypeId);
			urlBuilder.append("&contentId="+contentId); 
					
			URL url = new URL(urlBuilder.toString());
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Content-type", "application/xml");
						
			BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			StringBuilder sb = new StringBuilder();
			while (true) {
			    String line = br.readLine();
			    if (line == null)
			        break;
			    sb.append(line);
			}
			xml = sb.toString();
			br.close();
			conn.disconnect();
			
			org.json.JSONObject xmlJSONObj = XML.toJSONObject(sb.toString());
	        String xmlJSONObjString = xmlJSONObj.toString();
	      	        
	        ObjectMapper objectMapper = new ObjectMapper();
	        Map<String, Object> map = new HashMap<String, Object>();
	        map = objectMapper.readValue(xmlJSONObjString, new TypeReference<Map<String, Object>>(){});	       
	        Map<String, Object> dataResponse = (Map<String, Object>) map.get("response");
	        Map<String, Object> body = (Map<String, Object>) dataResponse.get("body");
	        Map<String, Object> items = (Map<String, Object>) body.get("items");
	        Map<String, Object> itemList =  (Map<String, Object>) items.get("item");
	        
	        	       
	        String keyString[] = {"contentid","contenttypeid", "chkbabycarriage", "accomcount",
	        		"chkcreditcard", "chkpet", "expguide" , "heritage1", "heritage2", "heritage3",
	        		"infocenter", "opendate", "parking", "restdate", "expagerange", "useseason",
	        		"usetime", "agelimit", "bookingplace", "discountinfofestival", "eventenddate",
	        	    "eventhomepage", "eventplace", "eventstartdate","festivalgrade", "placeinfo",
	        	    "playtime", "program", "spendtimefestival", "sponsor1", "sponsor1tel", "sponsor2",
	        	    "sponsor2tel", "subevent","usetimefestival", "chkbabycarriageculture", "accomcountculture",
	        	    "chkcreditcardculture", "chkpetculture", "infocenterculture", "parkingculture", "parkingfee", 
	        	    "usefee", "restdateculture", "spendtime", "scale", "usetimeculture", "distance", "infocentertourcourse",
	        	    "schedule", "theme", "taketime", "accomcountleports", "chkbabycarriageleports", "chkcreditcardleports", 
	        	    "chkpetleports", "expagerangeleports", "infocenterleports", "parkingfeeleports", "parkingleports",
	        	    "openperiod", "reservation", "restdateleports", "usefeeleports", "scaleleports", "usetimeleports"};
	        
	       //	json 키값을 배열에 저장 (데이터베이스에 컬럼명)  
	       for(int i=0; i<keyString.length; i++){
	    	   boolean keycheck = itemList.containsKey(keyString[i]);
	       		if(keycheck==false){
	       			itemList.put(keyString[i], "empty");
	       		}//	키가 없을 경우 값도 없는 경우이니 키를 생성해주면서 값을 empty로 넣어줌(varchar2)
	       		
	       		String temp = itemList.get(keyString[i]).toString();
	       		//	키에 대한 값이 없을 경우 null 값인 "empty"를 넣어줌
	       		if(temp==null || temp.length()==0 || temp == ""){
	       			itemList.put(keyString[i], "empty");
	       		}
	        }
	       		
	        String contentid = itemList.get("contentid").toString();
	       	if(contentid.equals("empty")){
	       		itemList.put("contentid", "9999");
	       	}	//	데이터가 전부 varchar2(String)이기 때문에 숫자형 데이터로 형변환 하기전	
	       		//	"empty" 값을	"9999"로 설정하고	데이터베이스에 저장할때	숫자로 형변환
	       	String contenttypeid = itemList.get("contenttypeid").toString();
	   		if(contenttypeid.equals("empty")){
	   			itemList.put("contenttypeid", "9999");
	   		}
	   		
	       
	        
	        db = new JDBCUtil();
	        con = db.getCON(ourl, id, pw);
	        String sql = "insert into TravelIntroTbl values " +
	        			"( ? , ? , ?, ?, ?, ?, ?, ?, ?, ?, " +
	        			"  ? , ? , ?, ?, ?, ?, ?, ?, ?, ?, " +
	        			"  ? , ? , ?, ?, ?, ?, ?, ?, ?, ?, " +
	        			"  ? , ? , ?, ?, ?, ?, ?, ?, ?, ?, " +
	        			"  ? , ? , ?, ?, ?, ?, ?, ?, ?, ?, " +
	        			"  ? , ? , ?, ?, ?, ?, ?, ?, ?, ?, " +
	        			"  ? , ? , ?, ?, ?, ? )";
	        pstmt = db.getPSTMT(con, sql);
	    	        
	        for(int i=1; i<keyString.length+1; i++){
	        	if(i == 1 || i== 2){
	        		pstmt.setInt(i, (int)itemList.get(keyString[i-1]));
	        	}else{
	        		pstmt.setString(i, itemList.get(keyString[i-1]).toString());
	        	}
	        }
	       	       
	        pstmt.executeQuery();
	        db.close(pstmt);
	        db.close(con);
	       
	        System.out.println("	DetailIntroDataTravel	success");
	        
		} catch(Exception e){
		 System.out.println(e); 
		}
	 }
}
	        